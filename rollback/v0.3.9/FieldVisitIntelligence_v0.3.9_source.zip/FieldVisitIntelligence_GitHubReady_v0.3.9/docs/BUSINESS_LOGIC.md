# Business Logic — Field Visit Intelligence v0.3.9

## Objective
Validate what actually happens at the outlet after/around Non-EC, quantify EC/SC behavior, and distinguish operational miscoding from gaps in the SFA/E-Work reason taxonomy.

## Separation of reason dimensions

### Actual / Observed Reason
Captured first, before the observer checks the SFA choice. It describes the field-observed root cause using the research taxonomy.

### Exact SFA / E-Work Reason
Captured second and must reproduce the exact option selected by the salesman:
- Pemilik tidak ada ditempat
- Nanti ditelpon saja
- Barang masih ada
- Toko tidak ada uang
- Toko Tutup
- Ambil dari supplier lain
- Lainnya

The observer must not translate an SFA choice into an analytical category.

## Legacy recovery rule
Pre-v0.3.9 calls remain on the same Call ID and retain their original `sfa_reason_code`.

Safe auto-recovery:
- stock → Barang masih ada
- financial → Toko tidak ada uang
- closed → Toko Tutup

No automatic recovery for PIC, Other, Unclear, Price, Refusal, Product or Competitor because the exact historical SFA choice is not provable from the legacy category alone.

## Recovery states
- `EXACT_CAPTURED`: new direct exact-SFA capture.
- `AUTO_RECOVERED`: conservative one-to-one reconstruction of a legacy row.
- `MANUAL_CONFIRMED`: an Admin/JOVIS edit confirms the historical exact SFA choice.
- `UNRESOLVED`: exact SFA choice is still unknown.

## v0.3.9 alignment logic
For causal exact SFA reasons:

| Exact SFA | Expected Actual Reason |
|---|---|
| Pemilik tidak ada ditempat | PIC Tidak Tersedia |
| Barang masih ada | Stok Masih Tersedia |
| Toko tidak ada uang | Kendala Keuangan / Cash |
| Toko Tutup | Toko Tutup |
| Ambil dari supplier lain | **Belum dipetakan otomatis**; actual taxonomy saat ini belum membedakan supplier/grosir/competitor secara cukup presisi |

- Primary actual reason = expected reason → `MATCH`.
- Expected reason only appears as contributing factor → `PARTIAL`.
- Another actual reason → `MISMATCH` only when the exact SFA reason has an approved one-to-one actual mapping.
- `Ambil dari supplier lain` currently returns `UNCLEAR` for reason accuracy until the business mapping to actual taxonomy is explicitly approved.
- Missing/unclear actual reason → `UNCLEAR`.
- No exact historical SFA → `UNRESOLVED`.
- `Nanti ditelpon saja` → `NON_CAUSAL`, because it describes a disposition/follow-up rather than a root cause.
- `Lainnya` → `TAXONOMY_GAP`, because it is the channel for an SFA reason not explicitly represented.

Mismatch percentages use only `MATCH + PARTIAL + MISMATCH` as the comparable denominator.

## Other retained rules
- Omzet is mandatory for EC.
- New calls require successful GPS check-in before entry and GPS checkout when saved.
- `Kode Toko` is stored as `C` + digits.
- One JOVIS account may have one active visit.
- Admin soft-delete remains auditable and reconciles across devices.
- Raw `Other/Lainnya` actual wording and evidence are preserved for later taxonomy clustering.
