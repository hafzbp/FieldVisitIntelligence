# Ready-to-Use Checklist — v0.3.9

## Deployment
- [ ] Migration 006 executed successfully in Supabase.
- [ ] GitHub Pages header shows v0.3.9.
- [ ] Old mobile tabs reopened once.
- [ ] Sync diagnostics show no unexpected error.

## Exact SFA smoke test
- [ ] New Non-EC call shows exactly seven SFA/E-Work choices.
- [ ] `Pemilik tidak ada ditempat` and `Nanti ditelpon saja` appear as separate options.
- [ ] Save one new Non-EC call and verify `sfa_capture_type=EXACT` and `sfa_recovery_status=EXACT_CAPTURED` in Supabase.

## Legacy recovery smoke test
- [ ] Admin shows SFA Legacy Recovery.
- [ ] Existing Stock/Financial/Closed rows appear auto-recovered after refresh.
- [ ] Ambiguous PIC/Lainnya/Tidak Jelas rows remain unresolved.
- [ ] Confirm one unresolved row manually.
- [ ] Same Call ID remains unchanged.
- [ ] JOVIS/device receives the correction after refresh/pull.

## Export
- [ ] Admin detailed export opens.
- [ ] `01_RAW_CALL_LOG` contains exact + legacy SFA fields.
- [ ] `03_REASON_ACCURACY` uses comparable-only denominator.
- [ ] `10_SFA_RECOVERY` is present.

## Existing feature regression
- [ ] GPS check-in blocks without permission.
- [ ] Checkout + dwell time save correctly.
- [ ] Kode Toko C-prefix works.
- [ ] Admin delete still reconciles to JOVIS device.
