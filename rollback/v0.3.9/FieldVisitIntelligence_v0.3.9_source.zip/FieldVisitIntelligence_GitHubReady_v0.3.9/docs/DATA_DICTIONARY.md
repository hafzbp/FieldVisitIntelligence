# Data Dictionary — Field Visit Intelligence v0.3.9

## visits
| Field | Meaning |
|---|---|
| id | UUID visit |
| jovis_user_id | Authenticated owner |
| visit_date | Business visit date |
| depot | Area / depot |
| salesman_name | Salesman observed |
| salesman_id | Optional salesman ID |
| start_time | Captured when visit starts |
| end_time | Captured when visit ends |
| status | active / completed |
| is_deleted | Soft-delete tombstone |

## calls — core
| Field | Meaning |
|---|---|
| id | UUID call; unchanged during v0.3.9 recovery |
| visit_id | Parent visit |
| jovis_user_id | Record owner |
| outlet_id | Canonical Kode Toko (`C` + digits) |
| outlet_name | Outlet name |
| route_status | JKS / OFF_ROUTE |
| result | EC / NON_EC |
| omzet | Mandatory for EC |
| observed_reason_code | Primary actual Non-EC reason |
| custom_real_reason | Required raw actual reason when observed = Other |
| contributing_factor | Optional secondary actual factor |
| evidence | Factual field evidence |
| sfa_reason_code | Original/current SFA code. On legacy rows this remains the pre-v0.3.9 interpreted value; on new exact rows it carries the exact `sfa_*` code for backward compatibility. |
| sfa_reason_exact_code | Exact E-Work/SFA code when known |
| sfa_capture_type | EXACT / LEGACY |
| sfa_recovery_status | EXACT_CAPTURED / AUTO_RECOVERED / MANUAL_CONFIRMED / UNRESOLVED |
| reason_match_status | Historical/database-compatible MATCH / PARTIAL / MISMATCH / UNCLEAR. v0.3.9 analysis derives its own alignment from exact SFA. |
| sfa_selection_reason | Why the salesman selected the SFA reason, if known |
| revisit_plan | Planned follow-up |
| can_revisit_earlier | YES / NO / UNKNOWN |
| followup_timing_reason | Signal/reason determining revisit timing |
| quick_note | Optional operational note |

## Exact SFA codes
| Code | Exact label |
|---|---|
| sfa_owner_absent | Pemilik tidak ada ditempat |
| sfa_call_later | Nanti ditelpon saja |
| sfa_stock_available | Barang masih ada |
| sfa_no_cash | Toko tidak ada uang |
| sfa_store_closed | Toko Tutup |
| sfa_other_supplier | Ambil dari supplier lain |
| sfa_other | Lainnya |

## GPS / dwell fields
| Field | Meaning |
|---|---|
| checkin_at | Check-in timestamp after mandatory geolocation succeeds |
| checkout_at | Checkout timestamp after geolocation succeeds |
| checkin_latitude / longitude | Check-in coordinates |
| checkin_accuracy_m | Browser-reported check-in accuracy |
| checkout_latitude / longitude | Checkout coordinates |
| checkout_accuracy_m | Browser-reported checkout accuracy |
| duration_seconds | checkout_at − checkin_at |
| call_timestamp | Backward-compatible timestamp; new calls use checkin_at |

## Derived analysis states (not required database values)
| State | Meaning |
|---|---|
| MATCH | Exact causal SFA reason corresponds to primary actual reason |
| PARTIAL | Exact causal SFA reason corresponds to contributing factor |
| MISMATCH | Exact causal SFA reason conflicts with actual reason |
| UNCLEAR | Insufficient comparable actual information |
| UNRESOLVED | Exact historical SFA choice not recovered |
| NON_CAUSAL | SFA `Nanti ditelpon saja` |
| TAXONOMY_GAP | SFA `Lainnya` |
