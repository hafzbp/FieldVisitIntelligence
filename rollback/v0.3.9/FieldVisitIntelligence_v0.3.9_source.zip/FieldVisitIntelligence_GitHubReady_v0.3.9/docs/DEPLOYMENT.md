# Deployment — Field Visit Intelligence v0.3.9

## Required order

1. Verify migrations 001–005 are already applied.
2. In Supabase SQL Editor, run:
   `supabase/migrations/202608120006_exact_sfa_legacy_recovery.sql`
3. Expected result: `Success. No rows returned`.
4. Do not clear browser/site data while any JOVIS/Admin Sync Queue has Pending/Error rows.
5. Upload/replace the GitHub Pages repository contents with v0.3.9.
6. Confirm the app header shows `v0.3.9`.
7. Close/reopen old mobile tabs once so the network-first service worker converges to the new assets.
8. Admin → Refresh Data → open `SFA Legacy Recovery`.
9. Confirm one ambiguous legacy row as a smoke test.
10. Export consolidated detail and verify `10_SFA_RECOVERY` exists.

## Migration behavior
Migration 006 is additive. It does not regenerate IDs or replace field evidence. During the one-time backfill, existing call touch/audit triggers are temporarily disabled so historical editor/audit timestamps are not falsely rewritten by the migration itself, then re-enabled before commit.

## Cutover safety
A database trigger added by migration 006 populates provenance if an older frontend submits one of the new exact `sfa_*` codes during the migration/frontend deployment window.

## Rollback
See `ROLLBACK.md` before reverting. Migration 006 adds columns and taxonomy rows; a frontend rollback can be done without deleting those additive fields.
