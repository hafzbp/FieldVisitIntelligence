# Rollback — Field Visit Intelligence v0.3.9

## Rollback target
v0.3.8

Backup included:
`rollback/v0.3.8/FieldVisitIntelligence_v0.3.8_source.zip`

## Data safety
Migration 006 is additive. Existing field data and legacy SFA values remain in the original calls. The new columns/taxonomy rows can safely remain in Supabase during a frontend rollback.

Do **not** clear browser/site data if any Sync Queue contains Pending/Error rows.

## Frontend rollback
1. Stop new field entry during rollback window if practical.
2. Restore v0.3.8 frontend files from the bundled rollback zip or Git history.
3. Push to GitHub Pages.
4. Confirm header shows `v0.3.8`.
5. Reopen mobile tabs and run Sync diagnostic.

## Database rollback recommendation
Do not drop migration-006 columns or recovered data during an emergency frontend rollback. They are backward-compatible additive fields. Leaving the exact taxonomy rows in place may cause v0.3.8 to show the exact SFA options, but v0.3.8 analytical match logic is not valid for those codes. Therefore v0.3.8 rollback should be treated as operational-entry fallback only, not trusted reason-accuracy reporting.

## Validation after rollback
- Confirm visits/calls remain visible according to RLS.
- Confirm pending queues are preserved.
- Confirm no Call/Visit IDs changed.
- Do not use v0.3.8 reason mismatch output as authoritative once exact `sfa_*` rows exist.
