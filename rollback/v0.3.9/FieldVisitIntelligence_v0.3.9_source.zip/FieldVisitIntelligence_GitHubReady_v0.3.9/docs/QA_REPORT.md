# QA Report — Field Visit Intelligence v0.3.9

## Release purpose
Exact SFA/E-Work taxonomy correction with backward-compatible legacy recovery.

## Automated/static QA actually executed

| Suite | Result |
|---|---:|
| `tests/unit/test_v034.py` — sync reliability regression | 21 PASS / 0 FAIL |
| `tests/unit/test_v037.py` — GPS/Kode Toko/dwell regression | 41 PASS / 0 FAIL |
| `tests/unit/test_v038.py` — tombstone/cross-device regression | 28 PASS / 0 FAIL |
| `tests/unit/test_v039.py` — exact SFA + recovery | 31 PASS / 0 FAIL |
| Synthetic detailed-export XML parse | PASS |

**Automated assertions: 121 PASS / 0 FAIL, plus 1 export-integration PASS.**

## v0.3.9 verified checks
- Exact SFA list contains the seven supplied E-Work choices.
- Observed taxonomy and exact SFA taxonomy are separated.
- Safe auto-recovery is limited to `stock`, `financial`, and `closed`.
- PIC is not auto-mapped.
- Legacy SFA value remains preserved.
- Cloud payload includes all three new provenance fields.
- Migration 006 adds those fields and exact-SFA constraints.
- Migration includes a cutover trigger for older frontend writes after migration.
- Admin legacy recovery UI exists.
- New call entry explicitly asks for exact SFA/E-Work wording.
- `Nanti ditelpon saja` is classified as `NON_CAUSAL` for analysis.
- `Lainnya` is classified as `TAXONOMY_GAP` for analysis.
- unresolved legacy calls are excluded from forced mismatch.
- export contains exact/legacy/recovery/alignment columns.
- export contains `10_SFA_RECOVERY`.
- synthetic export builds valid SpreadsheetML XML with 11 sheets.
- JavaScript syntax passes `node --check`.
- no Supabase secret/service-role key value is present.
- v0.3.4, v0.3.7 and v0.3.8 regression assertions remain PASS.

## User-export recovery rehearsal
Using the supplied `FVI_Consolidated_Detail_2026-08-12.xls`, the same conservative recovery rules produce:
- 71 calls total.
- 34 Non-EC.
- 23 safe auto-recovery candidates.
- 11 unresolved legacy SFA rows.
- Among the 23 comparable auto-recovered rows: 18 MATCH and 5 MISMATCH.

This is a local analytical rehearsal against the export, **not proof that migration 006 has run in Supabase**.

## BLOCKED / real-environment verification
These tests were not executed and are not marked PASS:

1. **BLOCKED — Supabase migration execution:** run `202608120006_exact_sfa_legacy_recovery.sql` in the real project.
2. **BLOCKED — authenticated Admin recovery write:** confirm one unresolved call and verify the same Call ID updates in Supabase and JOVIS cache.
3. **BLOCKED — new Non-EC field flow on deployed site:** confirm only the seven exact SFA options appear.
4. **BLOCKED — real mobile GPS:** check-in/checkout permission and coordinates on the actual phone browser.
5. **BLOCKED — real consolidated export:** export after migration and verify `10_SFA_RECOVERY` plus exact/legacy columns in Excel.

## Release assessment
**Code/static/unit/regression: PASS.**
Deployment readiness is conditional on migration 006 plus the five smoke tests above.
