# Known Limitations — v0.3.9

1. Migration 006 and authenticated Supabase workflows cannot be executed from the build container; production verification is BLOCKED until deployment.
2. Real iOS/Android GPS permission and checkout capture still require device testing.
3. Historical ambiguous SFA choices cannot be reconstructed reliably if neither the observer nor evidence can establish the exact option; those rows must remain `UNRESOLVED`.
4. `Nanti ditelpon saja` is a disposition/follow-up rather than a causal reason, so it is excluded from causal mismatch accuracy.
5. Exact SFA `Lainnya` is treated as a taxonomy-gap channel; semantic clustering still occurs later in ChatGPT/business review, not automatically in the app.
6. Actual post-Non-EC recovery outcome is not yet linked automatically to a later call.
7. Admin dashboard is periodic/on-demand, not realtime streaming.
8. `@supabase/supabase-js` remains loaded from a pinned CDN ESM URL.
9. The separate SFA screen field `Permintaan order Melalui` shown in the reference screenshot is not included in v0.3.9 because this release only corrects the Non-EC reason dimension.
