# Field Visit Intelligence v0.3.9

Mobile-first field visit application for EC/SC 90% Non-EC validation.

## Release focus — Exact SFA / E-Work taxonomy recovery
v0.3.9 fixes the SFA-reason capture design without deleting or replacing existing field data.

### Exact SFA / E-Work options
New Non-EC calls use the exact seven options supplied by the Product Owner:

1. Pemilik tidak ada ditempat
2. Nanti ditelpon saja
3. Barang masih ada
4. Toko tidak ada uang
5. Toko Tutup
6. Ambil dari supplier lain
7. Lainnya

The observational/actual-reason taxonomy remains separate.

### Existing data is preserved
Existing `Visit ID`, `Call ID`, GPS, timestamps, duration, omzet, actual reason, evidence, follow-up and legacy SFA values are not replaced.

Migration 006 adds:
- `sfa_reason_exact_code`
- `sfa_capture_type`
- `sfa_recovery_status`

Safe one-to-one legacy mappings are auto-recovered:
- `Stok Masih Tersedia` → `Barang masih ada`
- `Kendala Keuangan / Cash` → `Toko tidak ada uang`
- `Toko Tutup` → `Toko Tutup`

Ambiguous legacy rows stay `UNRESOLVED` and appear in the Admin **SFA Legacy Recovery** queue for manual confirmation.

## Analysis logic in v0.3.9
Reason accuracy is calculated only when an exact SFA reason is available and causally comparable with the observed reason.

- `MATCH`, `PARTIAL`, `MISMATCH`: included in comparable reason accuracy.
- `UNRESOLVED`: legacy exact SFA choice is still unknown.
- `NON_CAUSAL`: exact SFA option `Nanti ditelpon saja`; treated as a disposition/follow-up rather than a root cause.
- `TAXONOMY_GAP`: exact SFA option `Lainnya`; treated as a missing-taxonomy channel rather than forced mismatch.

The historical `reason_match_status` column remains available for provenance but v0.3.9 analysis derives alignment from exact SFA + actual reason.

## Repository layout

```text
index.html
assets/
src/
supabase/migrations/
tests/
docs/
rollback/
version.json
sw.js
manifest.webmanifest
```

## Required deployment order
1. Confirm migrations 001–005 are already applied.
2. Run `supabase/migrations/202608120006_exact_sfa_legacy_recovery.sql` in Supabase SQL Editor.
3. Confirm `Success. No rows returned`.
4. Upload the v0.3.9 repository contents to GitHub Pages.
5. Confirm the header shows `v0.3.9`.
6. Admin → refresh data → review **SFA Legacy Recovery**.
7. Confirm unresolved historical rows when the exact SFA choice can still be established.

Do not clear browser/site data while the Sync Queue contains Pending/Error rows.

## Security
Only the Supabase Project URL and Publishable Key may be stored in the frontend repository. Never store a Supabase Secret key, service-role key, database password or user password in GitHub.

## Related docs
- `docs/PATCH_NOTES_v0.3.9.md`
- `docs/QA_REPORT.md`
- `docs/BUSINESS_LOGIC.md`
- `docs/DATA_DICTIONARY.md`
- `docs/ARCHITECTURE.md`
- `docs/DEPLOYMENT.md`
- `docs/ROLLBACK.md`
- `docs/LEGACY_RECOVERY_PREVIEW_2026-08-12.md`
