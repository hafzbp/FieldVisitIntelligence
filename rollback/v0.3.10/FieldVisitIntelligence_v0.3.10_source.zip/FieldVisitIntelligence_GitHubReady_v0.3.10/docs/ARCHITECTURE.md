# Architecture — Field Visit Intelligence v0.3.10

```text
GitHub Pages
  |
  |-- Supabase Auth session
  |-- IndexedDB local cache / draft / sync queue
  |-- Actual-reason taxonomy
  |-- Exact SFA/E-Work taxonomy
  |-- Deterministic recovery + alignment engine
  |-- Detailed SpreadsheetML export
  |
  +--> Supabase
       |-- Auth
       |-- Postgres
       |-- Row Level Security
       |-- Audit / integrity triggers
       |-- Exact-SFA provenance fields
```

## Sources of truth
- Operational/cloud source: Supabase Postgres.
- Offline resilience: IndexedDB cache + pending queue.
- Exact SFA vocabulary: `reason_taxonomy` rows with `reason_type='sfa'`.
- Actual vocabulary: `reason_taxonomy` rows with `reason_type='observed'`.
- Legacy provenance: original `calls.sfa_reason_code` plus v0.3.9 recovery fields.

## Save flow
User Save → IndexedDB → queue → UI continues → Supabase UPSERT → queue removed after acknowledgement.

## Legacy recovery flow
Existing Call → migration adds provenance → safe one-to-one categories get exact code → ambiguous rows remain unresolved → Admin recovery confirmation updates the same Call ID → local queue → Supabase → all clients receive updated row on refresh/pull.

## Cutover compatibility
Migration 007 contains the exact-SFA provenance trigger and is standalone after the failed 006 attempt. Historical backfill is limited to live Calls under live Visits. Tombstone and Call-parent integrity guards remain enabled. If an older frontend writes an exact `sfa_*` code during cutover, provenance is populated server-side. Old observational taxonomy rows are `reason_type='observed'`, while the exact options are `reason_type='sfa'`.

## Analysis flow
Call rows → actual reason normalization → exact SFA resolution → v0.3.9 alignment → comparable denominator → findings/UI/export.

`reason_match_status` is retained for compatibility/audit but is not the analytical source of truth for v0.3.9 reason accuracy.

## Security
The frontend contains only the Supabase URL and publishable key. RLS remains authoritative. No secret/service-role key is stored in the repo.
