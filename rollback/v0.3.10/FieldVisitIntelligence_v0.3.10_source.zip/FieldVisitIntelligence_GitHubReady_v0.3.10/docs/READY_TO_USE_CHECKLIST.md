# Ready-to-Use Checklist — v0.3.10

## Database patch
- [ ] Migration 007 executed successfully in Supabase without `42501`.
- [ ] Verification SQL executed.
- [ ] `active_calls_under_deleted_visit = 0`.
- [ ] Deleted testing visits remain absent from active JOVIS/Admin data.

## Deployment
- [ ] GitHub Pages header shows v0.3.10.
- [ ] Old mobile tabs reopened once.
- [ ] Sync diagnostics show no unexpected error.

## Exact SFA smoke test
- [ ] New Non-EC call shows exactly seven SFA/E-Work choices.
- [ ] `Pemilik tidak ada ditempat` and `Nanti ditelpon saja` are separate options.
- [ ] Save one new Non-EC call and verify `sfa_capture_type=EXACT` and `sfa_recovery_status=EXACT_CAPTURED`.

## Legacy recovery smoke test
- [ ] Admin shows SFA Legacy Recovery.
- [ ] Existing live Stock/Financial/Closed rows appear auto-recovered after refresh.
- [ ] Ambiguous PIC/Lainnya/Tidak Jelas rows remain unresolved.
- [ ] Deleted calls/visits do not appear in the recovery queue.
- [ ] Confirm one unresolved row manually and verify the same Call ID remains unchanged.

## Export
- [ ] Admin detailed export opens.
- [ ] `01_RAW_CALL_LOG` contains exact + legacy SFA fields.
- [ ] `03_REASON_ACCURACY` uses comparable-only denominator.
- [ ] `10_SFA_RECOVERY` is present.

## Existing feature regression
- [ ] GPS check-in blocks without permission.
- [ ] Checkout + dwell time save correctly.
- [ ] Kode Toko C-prefix works.
- [ ] Admin delete still reconciles to JOVIS device.
