# Rollback — Field Visit Intelligence v0.3.10

## Rollback target
v0.3.9 source backup is included at:
`rollback/v0.3.9/FieldVisitIntelligence_v0.3.9_source.zip`

However, v0.3.9 Migration 006 is known to fail when tombstones exist. Do not rerun Migration 006 during rollback.

## Data safety
Migration 007 is additive and preserves existing calls/visits. The new SFA provenance columns and taxonomy rows can remain in Supabase during a frontend rollback.

Do **not** clear browser/site data if any Sync Queue contains Pending/Error rows.

## Frontend rollback
1. Stop new field entry during rollback window if practical.
2. Restore v0.3.9 frontend files from the bundled rollback zip or Git history.
3. Do **not** execute the archived failed Migration 006.
4. Push frontend to GitHub Pages.
5. Reopen mobile tabs and run Sync diagnostic.

## Database rollback recommendation
Do not drop Migration-007 columns or recovered data during an emergency frontend rollback. Dropping provenance would create more risk than leaving backward-compatible additive fields in place.

## Validation after rollback
- Confirm visits/calls remain visible according to RLS.
- Confirm pending queues are preserved.
- Confirm no Call/Visit IDs changed.
- Confirm deleted test/history records remain deleted on all devices.
