# Deployment — Field Visit Intelligence v0.3.10

## Required order

1. Verify migrations 001–005 are already applied.
2. **Do not rerun `202608120006_exact_sfa_legacy_recovery.sql`.** It is a known failed migration and is not in the active v0.3.10 migration folder.
3. In Supabase SQL Editor, run:
   `supabase/migrations/202608120007_exact_sfa_legacy_recovery_tombstone_safe.sql`
4. Expected successful execution: no `42501` tombstone error and transaction completes.
5. Run:
   `supabase/verification/202608120007_verify.sql`
6. Review:
   - live Non-EC / auto-recovered / unresolved counts;
   - `deleted_calls_with_recovery_fields` (existing pre-patch values may only be non-zero if another environment previously ran 006 successfully; Migration 007 itself does not add them);
   - `active_calls_under_deleted_visit` should be `0` under the v0.3.8 integrity model.
7. Do not clear browser/site data while any JOVIS/Admin Sync Queue has Pending/Error rows.
8. Upload/replace the GitHub Pages repository contents with v0.3.10.
9. Confirm the app header shows `v0.3.10`.
10. Reopen old mobile tabs once so the network-first service worker converges to the new assets.
11. Admin → Refresh Data → open `SFA Legacy Recovery`.
12. Confirm one ambiguous legacy row as an authenticated smoke test.
13. Export consolidated detail and verify `10_SFA_RECOVERY` exists.

## Migration behavior
Migration 007 is standalone and idempotent. It can run after the user's failed Migration 006 because that failed transaction did not commit. It can also run safely on an environment where 006 had already succeeded.

During one-time backfill, only the call touch/audit triggers are temporarily disabled so historical editor/audit timestamps are not falsely rewritten. Tombstone and parent-integrity guards stay enabled.

## Rollback
See `ROLLBACK.md`. Database fields are additive; emergency rollback should normally restore the previous frontend without dropping columns or recovery provenance.
