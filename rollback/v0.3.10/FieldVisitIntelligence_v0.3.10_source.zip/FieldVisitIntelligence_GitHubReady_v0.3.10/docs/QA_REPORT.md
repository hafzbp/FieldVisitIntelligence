# QA Report — Field Visit Intelligence v0.3.10

## Release purpose
Tombstone-safe database migration for the v0.3.9 Exact SFA/E-Work + legacy recovery feature.

## Actual automated/static QA executed

| Suite | Actual result |
|---|---:|
| `tests/unit/test_v034.py` — sync reliability regression | 21 PASS / 0 FAIL |
| `tests/unit/test_v037.py` — GPS/Kode Toko/dwell regression | 41 PASS / 0 FAIL |
| `tests/unit/test_v038.py` — tombstone/cross-device regression | 28 PASS / 0 FAIL |
| `tests/unit/test_v039.py` — exact SFA + recovery regression | 31 PASS / 0 FAIL |
| `tests/unit/test_v0310.py` — Migration 007 tombstone compatibility | 25 PASS / 0 FAIL |
| Synthetic detailed-export generation | PASS |
| Synthetic SpreadsheetML XML parse | PASS |

**Automated/unit/static assertions: 146 PASS / 0 FAIL.**  
**Export integration checks: 2 PASS / 0 FAIL.**

Full captured evidence: `tests/evidence/v0.3.10_qa.txt`.

## v0.3.10 targeted checks actually verified
- Active migration folder no longer contains the known-failing Migration 006.
- Failed Migration 006 is preserved under `docs/failed_migrations/` for traceability.
- Migration 007 is transactional and standalone after a failed 006.
- Every historical `public.calls` backfill excludes soft-deleted calls.
- Every historical backfill requires a non-deleted parent Visit.
- Tombstone and Call-parent integrity triggers are not disabled by Migration 007.
- Runtime SFA provenance normalizer returns deleted rows unchanged.
- Conservative legacy recovery remains limited to Stock, Financial/Cash, and Store Closed.
- Exact seven E-Work/SFA choices remain unchanged from v0.3.9.
- Existing sync/tombstone reconciliation, GPS gate, dwell time, Kode Toko, Admin recovery UI and detailed export regression checks remain PASS.
- Synthetic export excludes a deleted call and retains `10_SFA_RECOVERY`.
- JavaScript syntax passes `node --check`.
- No Supabase secret/service-role key value is present in the repository.
- v0.3.9 source is bundled as rollback reference.

## Migration eligibility fixture
A deterministic fixture was tested with:
- one live Call under a live Visit;
- one deleted Call under a live Visit;
- one live Call under a deleted Visit.

Only the live Call under the live Visit was eligible for recovery backfill. Both tombstone cases were excluded.

## Real-environment status
The user's real v0.3.9 Migration 006 execution produced PostgreSQL `42501` from `guard_soft_delete_tombstone()`. That observed failure confirms the defect scenario, but **does not count as a PASS test for v0.3.10**.

The following remain unexecuted from this build environment:

| Test | Status | Reason |
|---|---|---|
| Run Migration 007 in the real Supabase project | **BLOCKED** | No authenticated production DB execution available from build container |
| Verify no `42501` after Migration 007 | **BLOCKED** | Requires real Supabase execution |
| Run `202608120007_verify.sql` against production data | **BLOCKED** | Requires real Supabase execution |
| Authenticated Admin legacy recovery update | **BLOCKED** | Requires real Admin session |
| New exact-SFA Non-EC save on deployed GitHub Pages | **BLOCKED** | Requires deployment/authenticated browser |
| Real iOS/Android GPS check-in/out | **BLOCKED** | Requires actual phone permission/location |
| Production consolidated export after migration | **BLOCKED** | Requires production data after Migration 007 |

## Acceptance criteria after user deployment
Migration patch is considered production-verified only after:
1. Migration 007 completes without `42501`.
2. Verification SQL shows `active_calls_under_deleted_visit = 0`.
3. Previously Admin-deleted testing visits remain hidden/deleted after JOVIS refresh.
4. Admin SFA Legacy Recovery loads existing live historical rows.
5. One new Non-EC call saves with an exact E-Work reason and syncs successfully.
6. Consolidated export contains the exact/legacy SFA fields and `10_SFA_RECOVERY`.

## Release assessment
**Code/static/unit/regression/export integration: PASS.**  
**Real Supabase and device smoke testing: BLOCKED pending user execution.**
