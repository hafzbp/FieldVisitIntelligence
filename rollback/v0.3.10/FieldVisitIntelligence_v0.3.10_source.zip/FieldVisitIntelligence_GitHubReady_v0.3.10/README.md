# Field Visit Intelligence v0.3.10

Mobile-first field visit application for EC/SC 90% Non-EC validation.

## Release focus — Tombstone-safe Exact SFA Recovery
v0.3.10 is a targeted patch over v0.3.9. It keeps the exact seven E-Work/SFA options and the legacy-recovery design, but fixes the database migration so historical recovery never attempts to edit Admin-deleted tombstones.

### Exact SFA / E-Work options
New Non-EC calls use the exact seven options supplied by the Product Owner:

1. Pemilik tidak ada ditempat
2. Nanti ditelpon saja
3. Barang masih ada
4. Toko tidak ada uang
5. Toko Tutup
6. Ambil dari supplier lain
7. Lainnya

The observational/actual-reason taxonomy remains separate.

## Why v0.3.10 was required
Migration 006 in v0.3.9 backfilled all historical `NON_EC` calls. A deleted testing record triggered the v0.3.8 `guard_soft_delete_tombstone()` protection, producing PostgreSQL error `42501`. The migration was wrapped in a transaction, so the failed run did not commit.

Migration 007 is standalone and idempotent. Every historical `calls` backfill now requires:
- `calls.is_deleted = false`; and
- the parent `visits.is_deleted = false`.

The tombstone/integrity guards remain enabled.

## Existing data is preserved
Existing `Visit ID`, `Call ID`, GPS, timestamps, duration, omzet, actual reason, evidence, follow-up and legacy SFA values are not replaced.

Migration 007 creates/uses:
- `sfa_reason_exact_code`
- `sfa_capture_type`
- `sfa_recovery_status`

Safe one-to-one legacy mappings remain:
- `Stok Masih Tersedia` → `Barang masih ada`
- `Kendala Keuangan / Cash` → `Toko tidak ada uang`
- `Toko Tutup` → `Toko Tutup`

Ambiguous legacy rows stay `UNRESOLVED` and appear in Admin **SFA Legacy Recovery**.

## Required deployment order
1. Confirm migrations 001–005 are already applied.
2. **Do not rerun Migration 006.** Its failed source is preserved only under `docs/failed_migrations/`.
3. Run `supabase/migrations/202608120007_exact_sfa_legacy_recovery_tombstone_safe.sql` in Supabase SQL Editor.
4. Run `supabase/verification/202608120007_verify.sql` and review the three result sets.
5. Upload/replace the GitHub Pages repository contents with v0.3.10.
6. Confirm the app header shows `v0.3.10`.
7. Admin → Refresh Data → review **SFA Legacy Recovery**.
8. Confirm one unresolved historical row only when the exact SFA choice can still be established.

Do not clear browser/site data while the Sync Queue contains Pending/Error rows.

## Security
Only the Supabase Project URL and Publishable Key may be stored in the frontend repository. Never store a Supabase Secret key, service-role key, database password or user password in GitHub.

## Related docs
- `docs/PATCH_NOTES_v0.3.10.md`
- `docs/QA_REPORT.md`
- `docs/BUSINESS_LOGIC.md`
- `docs/DATA_DICTIONARY.md`
- `docs/ARCHITECTURE.md`
- `docs/DEPLOYMENT.md`
- `docs/ROLLBACK.md`
- `docs/LEGACY_RECOVERY_PREVIEW_2026-08-12.md`
