# PATCH NOTES — v0.3.3

## Previous version
v0.3.2

## New version
v0.3.3

## Symptom
Application could fail at startup with:
`Failed to execute 'transaction' on 'IDBDatabase': The database connection is closing.`

## Root cause
The local IndexedDB helper cached a database connection indefinitely and separated transaction creation from request creation across async helper boundaries. If the browser moved the cached connection into a closing lifecycle state, later calls attempted to create transactions on that stale connection. The helper had no close/version-change invalidation or retry mechanism.

## Resolution
- Refactored local IndexedDB operations so transaction creation and the first request are enqueued synchronously in one operation.
- Detect closing/inactive IndexedDB errors.
- Invalidate and reopen the cached database connection automatically.
- Handle `versionchange` / connection close lifecycle events.
- Preserve database name/version and existing local data; no schema migration is required.

## Exact revised locations
- `src/data/local-db.js` — full IndexedDB connection/transaction helper refactor.
- `src/config/app-config.js` — version only.
- `sw.js` — cache version only.
- `version.json` — version only.

## Business logic impact
None intended. Visit/call/reason/omzet rules are unchanged.

## Data impact
No data reset or database migration. Existing `fvi_v030` IndexedDB records remain compatible.

## Rollback
Replace application files with v0.3.2. Database schema is unchanged.
