# QA Report — Field Visit Intelligence v0.3.3

| Test ID | Scenario | Expected Result | Actual Result | Status | Evidence / Notes |
|---|---|---|---|---|---|
| QA-330 | JS syntax | All application JS modules parse | `node --check` passed for all source JS + service worker | PASS | Executed locally |
| QA-331 | IndexedDB transaction architecture | Transaction creation and first request happen in the same synchronous operation | `runRequest()` creates transaction + request without an async helper gap | PASS | Static implementation inspection |
| QA-332 | Closing-connection recovery | Closing/inactive connection errors trigger connection invalidation + reopen/retry | Retry guards implemented for `InvalidStateError`, `TransactionInactiveError`, and closing-state messages | PASS | Static implementation inspection |
| QA-333 | IndexedDB lifecycle handling | Stale connection is not permanently reused | `versionchange` and `close` handlers invalidate cached handle/promise | PASS | Static implementation inspection |
| QA-334 | Existing local DB compatibility | Patch does not rename/reset local database | DB remains `fvi_v030`, DB_VERSION 1 | PASS | Config check |
| QA-335 | App version/cache consistency | App/export/service worker use v0.3.3 | Version metadata updated | PASS | Static check |
| QA-336 | Chromium IndexedDB runtime regression | CRUD/reopen flow completes in headless Chromium | Could not complete due container Chromium/DBus runtime hanging | BLOCKED | Environment limitation; not marked PASS |
| QA-337 | Supabase Auth/RLS/cloud sync | Real Admin + JOVIS sessions operate correctly | Not retested after frontend patch | BLOCKED | Requires redeploy + real browser sessions |

## Regression Result
No intended business-rule, Supabase schema, RLS, reason taxonomy, visit, call, omzet, or export-data logic change. Patch is limited to local IndexedDB lifecycle reliability plus version/cache metadata.

## Known Limitations
- Real-device verification is still required after GitHub Pages redeploy.
- Supabase RLS multi-account E2E remains pending.
